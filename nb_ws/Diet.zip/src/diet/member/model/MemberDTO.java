/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diet.member.model;

import java.sql.Timestamp;

/**
 *
 * @author STU-27
 */
public class MemberDTO {
    private int no;
    private String userid;
    private String name;
    private String pwd;
    private String hp;
    private Timestamp regDate;
    
    public MemberDTO(){
        
    }
    
    public MemberDTO(int no, String userid, String name, String pwd, String hp, Timestamp regDate) {
        this.no = no;
        this.userid = userid;
        this.name = name;
        this.pwd = pwd;
        this.hp = hp;
        this.regDate = regDate;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getHp() {
        return hp;
    }

    public void setHp(String hp) {
        this.hp = hp;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    @Override
    public String toString() {
        return "MemberDTO{" + "no=" + no + ", userid=" + userid + ", name=" + name + ", pwd=" + pwd + ", hp=" + hp + ", regDate=" + regDate + '}';
    }
    
    
    
    
    
}



