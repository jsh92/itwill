/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package MyLauncher.app.model;

import MyLauncher.app.main.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author jseun
 */
public class ReservedListDAO {
    
    public int reserve(ReservedListDTO dto) throws SQLException{
        Connection con=null;
        PreparedStatement ps=null;
        try{
            
            //1,2
            con=DBUtil.getConnection();
            
            String sql="insert into reservation(name,geustName, phone, roomType,price,discount,payment,payBy,checkIn,checkOut,place)\n" +
                    "values(?,?,?,?,?,?,?,?,?,?,?)";
            ps=con.prepareStatement(sql);
            
            ps.setString(1, dto.getName());
            ps.setString(2, dto.getGeustName());
            ps.setString(3, dto.getPhone());
            ps.setString(4, dto.getRoomType());
            ps.setString(5, dto.getPrice()+"");
            ps.setString(6, dto.getDiscount()+"");
            ps.setString(7, dto.getPayment()+"");
            ps.setString(8, dto.getPayBy());
            ps.setString(9, dto.getCheckIn());
            ps.setString(10, dto.getCheckOut());
            ps.setString(11, dto.getPlace());
            
            int cnt= ps.executeUpdate();
            System.out.println("회원가입 결과, cnt="+cnt);
            return cnt;
        }finally{
            DBUtil.dbClose(ps, con);
        }
    };
    
    
}//main
